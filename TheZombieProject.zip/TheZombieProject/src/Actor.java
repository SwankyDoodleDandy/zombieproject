public class Actor {
String team;
int health;
int attack;
	public Actor() {
		this.team = team;
		this.health = health;
		this.attack = attack; 
	}
	
	public void attack() {
		
	}
        public void setHealth(int x){
            this.health = x;
        }
        public int getHealth(){
            return health;
        }
}
